We did not change much about our views. The only thing we changed was having the view reference interface types instead of concrete classes.
At first we used a Motion class and refered to it as Motion instead of IMotion. We did the same thing for shapes, we converted SimpleShapes 
into IShapes. 