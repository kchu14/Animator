Features:
All features that our providers implemented fully work on our model. One issue with the
providers view is the addition of a keyframe to a shape with no keyframes. In this case the
keyframe added is duplicated. Our providers told us that this was an unresolved issue in their
view, so we did not attempt to fix it. Other than that all other features work as intended in
their view.